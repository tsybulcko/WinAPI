﻿=== Genshin Impact Cursor Set ===

By: fegrifo

Download: http://www.rw-designer.com/cursor-set/gi

Author's description:

A set of cursors based on the standard Genshin Impact UI, containing the most commonly used arrow cursors.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.